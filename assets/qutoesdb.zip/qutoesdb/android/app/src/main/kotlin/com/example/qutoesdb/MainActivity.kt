package com.example.qutoesdb

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
