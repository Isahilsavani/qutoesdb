class AppUtil{
  static List<Map<String,dynamic>> quoteList = [];
  static List finalDataList = [];
  static int sec = 0;
}